/**
 * Skin Disease Classification System — script.js
 * Senior JavaScript Engineer · ES2022 · No dependencies
 */

'use strict';

/* ═══════════════════════════════════════════════════════════
   CONSTANTS & CONFIG
════════════════════════════════════════════════════════════ */
const API_ENDPOINT        = '/predict';
const ALLOWED_TYPES       = new Set(['image/jpeg', 'image/png', 'image/webp']);
const ALLOWED_EXTENSIONS  = /\.(jpe?g|png|webp)$/i;
const MAX_FILE_SIZE_MB    = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const TOAST_DURATION_MS   = 4000;
const ANIMATION_DELAY_MS  = 60; // stagger delay for probability bars

const RISK = Object.freeze({
  LOW    : { label: 'Low Risk',    className: 'risk-badge--low'    },
  MEDIUM : { label: 'Medium Risk', className: 'risk-badge--medium' },
  HIGH   : { label: 'High Risk',   className: 'risk-badge--high'   },
});

/* ═══════════════════════════════════════════════════════════
   DOM REFERENCES  (resolved once at startup)
════════════════════════════════════════════════════════════ */
const $  = (id) => document.getElementById(id);

const dom = Object.freeze({
  uploadArea          : $('uploadArea'),
  imageInput          : $('imageInput'),
  imagePreview        : $('imagePreview'),
  previewContainer    : $('previewContainer'),
  fileName            : $('fileName'),
  analyzeBtn          : $('analyzeBtn'),
  loadingContainer    : $('loadingContainer'),
  loadingSpinner      : $('loadingSpinner'),
  resultsSection      : $('resultsSection'),
  predictedClass      : $('predictedClass'),
  confidenceScore     : $('confidenceScore'),
  confidenceBar       : $('confidenceBar'),
  confidenceFill      : $('confidenceFill'),
  probabilityContainer: $('probabilityContainer'),
  diseaseDescription  : $('diseaseDescription'),
  recommendationText  : $('recommendationText'),
  riskLevel           : $('riskLevel'),
  resetBtn            : $('resetBtn'),
  uploadNewBtn        : $('uploadNewBtn'),
  toastContainer      : $('toastContainer'),
  removeImageBtn      : $('removeImageBtn'),
  currentYear         : $('currentYear'),
  themeToggle         : $('themeToggle'),
});

/* ═══════════════════════════════════════════════════════════
   APPLICATION STATE
════════════════════════════════════════════════════════════ */
let state = {
  file      : null,   // File | null
  isLoading : false,
};

/* ═══════════════════════════════════════════════════════════
   INITIALISATION
════════════════════════════════════════════════════════════ */
function init() {
  // Set current year in footer
  if (dom.currentYear) dom.currentYear.textContent = new Date().getFullYear();

  initTheme();
  bindUploadAreaEvents();
  bindFileInputEvent();
  bindAnalyzeButton();
  bindResultButtons();
  bindRemoveImageButton();
}

/* ═══════════════════════════════════════════════════════════
   THEME (dark / light)
════════════════════════════════════════════════════════════ */
function initTheme() {
  const saved = localStorage.getItem('skin-classifier-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  applyTheme(theme);

  if (dom.themeToggle) {
    dom.themeToggle.addEventListener('click', toggleTheme);
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('skin-classifier-theme', theme);

  if (dom.themeToggle) {
    dom.themeToggle.setAttribute(
      'aria-label',
      theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'
    );
  }
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  applyTheme(current === 'dark' ? 'light' : 'dark');
}

/* ═══════════════════════════════════════════════════════════
   EVENT BINDING
════════════════════════════════════════════════════════════ */
function bindUploadAreaEvents() {
  const area = dom.uploadArea;

  // Click / keyboard → open native file picker
  area.addEventListener('click', () => dom.imageInput.click());
  area.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      dom.imageInput.click();
    }
  });

  // Drag-and-drop visual feedback
  area.addEventListener('dragenter', (e) => { e.preventDefault(); area.classList.add('upload-area--drag-over'); });
  area.addEventListener('dragover',  (e) => { e.preventDefault(); area.classList.add('upload-area--drag-over'); });
  area.addEventListener('dragleave', (e) => {
    if (!area.contains(e.relatedTarget)) area.classList.remove('upload-area--drag-over');
  });
  area.addEventListener('drop', (e) => {
    e.preventDefault();
    area.classList.remove('upload-area--drag-over');
    const file = e.dataTransfer?.files?.[0];
    if (file) handleFileSelection(file);
  });
}

function bindFileInputEvent() {
  dom.imageInput.addEventListener('change', () => {
    const file = dom.imageInput.files?.[0];
    if (file) handleFileSelection(file);
    // Reset so the same file can be re-selected after removal
    dom.imageInput.value = '';
  });
}

function bindAnalyzeButton() {
  dom.analyzeBtn.addEventListener('click', handleAnalyze);
}

function bindResultButtons() {
  dom.resetBtn.addEventListener('click', resetAll);
  dom.uploadNewBtn.addEventListener('click', resetAll);
}

function bindRemoveImageButton() {
  if (dom.removeImageBtn) {
    dom.removeImageBtn.addEventListener('click', removeImage);
  }
}

/* ═══════════════════════════════════════════════════════════
   FILE HANDLING
════════════════════════════════════════════════════════════ */
function handleFileSelection(file) {
  if (!validateFile(file)) return;

  state.file = file;

  // Update filename label
  dom.fileName.textContent = file.name;

  // Show preview
  const reader = new FileReader();
  reader.onload = (e) => {
    dom.imagePreview.src  = e.target.result;
    dom.imagePreview.alt  = `Preview of ${file.name}`;
    dom.previewContainer.hidden = false;
    dom.previewContainer.classList.add('preview-container--visible');
  };
  reader.readAsDataURL(file);

  // Enable analyse button
  dom.analyzeBtn.disabled = false;
  dom.analyzeBtn.classList.add('btn--ready');

  showToast('Image selected successfully. Ready to analyse.', 'success');
}

function validateFile(file) {
  if (!ALLOWED_TYPES.has(file.type) && !ALLOWED_EXTENSIONS.test(file.name)) {
    showToast('Invalid file type. Please upload a JPEG, PNG, or WebP image.', 'error');
    return false;
  }
  if (file.size > MAX_FILE_SIZE_BYTES) {
    showToast(`File is too large. Maximum allowed size is ${MAX_FILE_SIZE_MB} MB.`, 'error');
    return false;
  }
  return true;
}

function removeImage() {
  state.file = null;
  dom.imagePreview.src   = '';
  dom.imagePreview.alt   = '';
  dom.previewContainer.hidden = true;
  dom.previewContainer.classList.remove('preview-container--visible');
  dom.fileName.textContent    = 'No file selected';
  dom.analyzeBtn.disabled     = true;
  dom.analyzeBtn.classList.remove('btn--ready');
}

/* ═══════════════════════════════════════════════════════════
   ANALYSE FLOW
════════════════════════════════════════════════════════════ */
async function handleAnalyze() {
  if (!state.file) {
    showToast('Please upload an image before analysing.', 'error');
    return;
  }
  if (state.isLoading) return;

  setLoadingState(true);

  try {
    const result = await postImageToAPI(state.file);
    renderResults(result);
    showToast('Analysis complete!', 'success');
    scrollToResults();
  } catch (err) {
    console.error('[SkinClassifier] API error:', err);
    const message = err instanceof NetworkError
      ? 'Network error — please check your connection and try again.'
      : err.message || 'An unexpected error occurred. Please try again.';
    showToast(message, 'error');
  } finally {
    setLoadingState(false);
  }
}

async function postImageToAPI(file) {
  const formData = new FormData();
  formData.append('image', file);

  let response;
  try {
    response = await fetch(API_ENDPOINT, {
      method : 'POST',
      body   : formData,
    });
  } catch (_) {
    throw new NetworkError('Unable to reach the server.');
  }

  if (!response.ok) {
    const detail = await safeParseError(response);
    throw new Error(detail || `Server error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  assertValidResponse(data);
  return data;
}

function assertValidResponse(data) {
  const required = ['predicted_class', 'confidence', 'probabilities', 'description', 'recommendation'];
  for (const key of required) {
    if (!(key in data)) throw new Error(`Malformed response from server (missing "${key}").`);
  }
}

async function safeParseError(response) {
  try {
    const ct   = response.headers.get('content-type') ?? '';
    const body = ct.includes('application/json') ? await response.json() : await response.text();
    return typeof body === 'string' ? body : (body?.detail ?? body?.message ?? null);
  } catch {
    return null;
  }
}

/* ═══════════════════════════════════════════════════════════
   RENDER RESULTS
════════════════════════════════════════════════════════════ */
function renderResults(data) {
  const { predicted_class, confidence, probabilities, description, recommendation } = data;

  // Primary result
  dom.predictedClass.textContent = predicted_class;
  dom.confidenceScore.textContent = `${confidence.toFixed(1)}%`;

  // Confidence bar (animate via rAF to ensure transition fires)
  dom.confidenceBar.setAttribute('aria-valuenow', confidence.toFixed(0));
  requestAnimationFrame(() => {
    dom.confidenceFill.style.width = `${Math.min(confidence, 100)}%`;
    setConfidenceColor(dom.confidenceFill, confidence);
  });

  // Risk badge
  setRiskBadge(confidence);

  // Probability bars
  renderProbabilityBars(probabilities);

  // Info card
  dom.diseaseDescription.textContent = description;
  dom.recommendationText.textContent  = recommendation;

  // Show results section
  dom.resultsSection.hidden = false;
  dom.resultsSection.classList.add('results-section--visible');
}

function setConfidenceColor(fill, confidence) {
  fill.classList.remove('confidence-fill--low', 'confidence-fill--medium', 'confidence-fill--high');
  if      (confidence > 80) fill.classList.add('confidence-fill--high');
  else if (confidence > 50) fill.classList.add('confidence-fill--medium');
  else                      fill.classList.add('confidence-fill--low');
}

function setRiskBadge(confidence) {
  const badge = dom.riskLevel;
  const { label, className } = getRisk(confidence);

  badge.textContent = label;
  badge.className   = 'risk-badge'; // reset
  badge.classList.add(className);
  badge.setAttribute('aria-label', `Risk level: ${label}`);
}

// ─── UPDATED MEDICAL RISK SCALE MAPPING ───
function getRisk(confidence) {
  if (confidence > 80) return RISK.HIGH;
  if (confidence >= 50) return RISK.MEDIUM;
  return RISK.LOW;
}

function renderProbabilityBars(probabilities) {
  const container = dom.probabilityContainer;
  container.innerHTML = '';

  // Sort by probability descending
  const sorted = Object.entries(probabilities).sort(([, a], [, b]) => b - a);

  sorted.forEach(([label, prob], index) => {
    const item = buildProbabilityBar(label, prob, index);
    container.appendChild(item);
  });
}

function buildProbabilityBar(label, prob, index) {
  const isTop = index === 0;

  const wrapper = document.createElement('div');
  wrapper.className = `prob-item${isTop ? ' prob-item--top' : ''}`;
  wrapper.setAttribute('aria-label', `${label}: ${prob.toFixed(1)}%`);

  const row = document.createElement('div');
  row.className = 'prob-row';

  const labelEl = document.createElement('span');
  labelEl.className   = 'prob-label';
  labelEl.textContent = label;

  const valueEl = document.createElement('span');
  valueEl.className   = 'prob-value';
  valueEl.textContent = `${prob.toFixed(1)}%`;

  row.append(labelEl, valueEl);

  const track = document.createElement('div');
  track.className = 'prob-track';
  track.setAttribute('role', 'presentation');

  const fill = document.createElement('div');
  fill.className = 'prob-fill';
  fill.style.width = '0%'; // start at zero for animation

  track.appendChild(fill);
  wrapper.append(row, track);

  // Stagger animation
  setTimeout(() => {
    requestAnimationFrame(() => {
      fill.style.width = `${Math.min(prob, 100)}%`;
    });
  }, index * ANIMATION_DELAY_MS);

  return wrapper;
}

/* ═══════════════════════════════════════════════════════════
   LOADING STATE
════════════════════════════════════════════════════════════ */
function setLoadingState(isLoading) {
  state.isLoading = isLoading;

  dom.loadingContainer.hidden = !isLoading;
  dom.analyzeBtn.disabled     = isLoading;
  dom.resetBtn.disabled       = isLoading;
  dom.uploadNewBtn.disabled = isLoading;

  dom.analyzeBtn.setAttribute('aria-busy', String(isLoading));

  if (isLoading) {
    dom.resultsSection.hidden = true;
    dom.resultsSection.classList.remove('results-section--visible');
    dom.loadingContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

/* ═══════════════════════════════════════════════════════════
   RESET
════════════════════════════════════════════════════════════ */
function resetAll() {
  // File state
  removeImage();

  // Results UI
  dom.resultsSection.hidden = true;
  dom.resultsSection.classList.remove('results-section--visible');

  // Reset result fields to placeholders
  dom.predictedClass.textContent    = '—';
  dom.confidenceScore.textContent   = '0%';
  dom.confidenceFill.style.width    = '0%';
  dom.confidenceFill.className      = 'confidence-fill';
  dom.confidenceBar.setAttribute('aria-valuenow', '0');
  dom.probabilityContainer.innerHTML = '';
  dom.diseaseDescription.textContent  = '—';
  dom.recommendationText.textContent  = '—';

  const badge       = dom.riskLevel;
  badge.textContent = '';
  badge.className   = 'risk-badge';

  // Loading
  dom.loadingContainer.hidden = true;

  // Buttons
  dom.analyzeBtn.disabled = true;
  dom.analyzeBtn.classList.remove('btn--ready');
  dom.resetBtn.disabled    = false;
  dom.uploadNewBtn.disabled = false;

  // Scroll back to top of page
  window.scrollTo({ top: 0, behavior: 'smooth' });

  showToast('Reset complete. Ready for a new image.', 'info');
}

/* ═══════════════════════════════════════════════════════════
   SCROLL HELPER
════════════════════════════════════════════════════════════ */
function scrollToResults() {
  dom.resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ═══════════════════════════════════════════════════════════
   TOAST NOTIFICATIONS
════════════════════════════════════════════════════════════ */
/**
 * @param {string} message
 * @param {'success'|'error'|'info'} type
 */
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.setAttribute('role', 'alert');
  toast.setAttribute('aria-live', 'assertive');
  toast.setAttribute('aria-atomic', 'true');

  const icon = document.createElement('span');
  icon.className   = 'toast__icon';
  icon.textContent = type === 'success' ? '✔' : type === 'error' ? '✖' : 'ℹ';
  icon.setAttribute('aria-hidden', 'true');

  const body = document.createElement('span');
  body.className   = 'toast__message';
  body.textContent = message;

  const close = document.createElement('button');
  close.type      = 'button';
  close.className = 'toast__close';
  close.setAttribute('aria-label', 'Dismiss notification');
  close.textContent = '✕';
  close.addEventListener('click', () => dismissToast(toast));

  toast.append(icon, body, close);
  dom.toastContainer.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('toast--visible'));
  });

  // Auto-dismiss
  const timer = setTimeout(() => dismissToast(toast), TOAST_DURATION_MS);
  toast._dismissTimer = timer;
}

function dismissToast(toast) {
  clearTimeout(toast._dismissTimer);
  toast.classList.remove('toast--visible');
  toast.classList.add('toast--hiding');
  toast.addEventListener('transitionend', () => toast.remove(), { once: true });
}

/* ═══════════════════════════════════════════════════════════
   CUSTOM ERROR TYPES
════════════════════════════════════════════════════════════ */
class NetworkError extends Error {
  constructor(message) {
    super(message);
    this.name = 'NetworkError';
  }
}

/* ═══════════════════════════════════════════════════════════
   BOOT
════════════════════════════════════════════════════════════ */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}